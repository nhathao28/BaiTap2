﻿using System.IO;
using System;
using System.Windows.Forms;
namespace Bai2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void loadFolderButton_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog dialog = new FolderBrowserDialog();
            var res = dialog.ShowDialog();

            if (res == DialogResult.OK)
            {
                var path = dialog.SelectedPath;
                Console.WriteLine("Selected Path: " + path); // Kiểm tra đường dẫn
                string[] files = Directory.GetFiles(path);

                foreach (var file in files)
                {
                    if (file.ToLower().EndsWith(".jpg") || file.ToLower().EndsWith(".png"))
                    {
                        PictureBox pictureBox = new PictureBox();
                        pictureBox.Size = new Size(100, 100); // Đặt kích thước
                        pictureBox.Cursor = Cursors.Hand;
                        pictureBox.Load(file);
                        pictureBox.SizeMode = PictureBoxSizeMode.StretchImage;
                        pictureBox.Tag = file;
                        pictureBox.Click += PictureBox_Click;

                        flowLayoutPanel1.Controls.Add(pictureBox);
                    }
                }
            }
        }

        private void PictureBox_Click(object sender, EventArgs e)
        {
            if (sender is PictureBox pictureBox)
            {
                string imgPath = pictureBox.Tag.ToString();
                pictureBox1.Load(imgPath);
                pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
                label1.Text = "File" + imgPath + "is Loaded. ";
            }
        }
    }
}
